package com.aamir.lostandfound;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Remove extends AppCompatActivity {

    Button btnRemove;
    TextView tvDescription,tvDate,tvLocation;
    DBsqLite dbSQLITE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove);

        tvDescription=(TextView) findViewById(R.id.tvDescription);
        tvDate=(TextView) findViewById(R.id.tvDate);
        tvLocation=(TextView) findViewById(R.id.tvLocation);
        btnRemove=(Button) findViewById(R.id.btnRemove);
        dbSQLITE=new DBsqLite(this);

        tvDescription.setText(getIntent().getStringExtra("description"));

        Cursor cursor=dbSQLITE.getItemData(tvDescription.getText().toString());
        while (cursor.moveToNext())
        {
            tvDate.setText(cursor.getString(1));
            tvLocation.setText(cursor.getString(2));
        }

        btnRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbSQLITE.deleteRecord("delete from tblLostFound where Description='"+ tvDescription.getText().toString()+"'");
            }
        });
    }
}