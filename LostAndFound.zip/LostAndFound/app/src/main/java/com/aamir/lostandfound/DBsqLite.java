package com.aamir.lostandfound;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DBsqLite extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "LostFound.db";

    public DBsqLite(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String sql;

        sql="CREATE TABLE tblLostFound (ID INTEGER PRIMARY KEY AUTOINCREMENT,Type TEXT,Name TEXT,Phone TEXT,Description Text,Date Text,Location TEXT)";
        sqLiteDatabase.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String sql="DROP TABLE if EXISTS tblLostFound";
        sqLiteDatabase.execSQL(sql);
    }

    public List<String> fillList()
    {
        List<String> data=new ArrayList<String>();
        data.add(0,"Select Lost or Found Item");
        String sql="select Description from tblLostFound order by ID";
        SQLiteDatabase db=getWritableDatabase();
        Cursor cursor=db.rawQuery(sql,null);

        if (cursor.moveToFirst())
        {
            do {
                data.add(cursor.getString(0));
            }while (cursor.moveToNext());
        }
        return  data;
    }

    public void insertData(String Type,String Name,String Phone,String Description,String Date,String Location)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("Type",Type);
        cv.put("Name",Name);
        cv.put("Phone",Phone);
        cv.put("Description",Description);
        cv.put("Date",Date);
        cv.put("Location",Location);
        db.insert("tblLostFound",null,cv);
        db.close();
    }

    public void deleteRecord(String sql)
    {
        SQLiteDatabase db=getWritableDatabase();
        db.execSQL(sql);
    }

    public Cursor getItemData(String Description)
    {
        SQLiteDatabase db=getWritableDatabase();
        String sql="select Description,Date,Location from tblLostFound where Description='"+ Description+"' ";
        Cursor cursor=db.rawQuery(sql,null);
        return cursor;
    }
}
