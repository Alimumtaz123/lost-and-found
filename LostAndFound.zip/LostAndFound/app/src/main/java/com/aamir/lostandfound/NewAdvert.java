package com.aamir.lostandfound;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class NewAdvert extends AppCompatActivity {

    RadioButton rbLost,rbFound;
    EditText etName,etPhone,etDescription,etDate,etLocation;
    Button btnSave;
    DBsqLite dbSQLITE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_advert);

        rbLost=(RadioButton) findViewById(R.id.rbLost);
        rbFound=(RadioButton) findViewById(R.id.rbFound);
        etName=(EditText) findViewById(R.id.etName);
        etPhone=(EditText) findViewById(R.id.etPhone);
        etDescription=(EditText) findViewById(R.id.etDescription);
        etDate=(EditText) findViewById(R.id.etDate);
        etLocation=(EditText) findViewById(R.id.etLocation);
        btnSave=(Button) findViewById(R.id.btnSave);
        dbSQLITE=new DBsqLite(this);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String txtType,txtName,txtPhone,txtDescription,txtDate,txtLocation;
                if(rbFound.isChecked())
                    txtType="Found";
                else
                    txtType="Lost";


                txtName=etName.getText().toString();
                txtPhone=etPhone.getText().toString();
                txtDescription=etDescription.getText().toString();
                txtDate=etDate.getText().toString();
                txtLocation=etLocation.getText().toString();

                dbSQLITE.insertData(txtType,txtName,txtPhone,txtDescription,txtDate,txtLocation);

                Toast.makeText(NewAdvert.this,"Record Save",Toast.LENGTH_LONG).show();
                etName.setText("");
                etPhone.setText("");
                etDescription.setText("");
                etDate.setText("");
                etLocation.setText("");
            }
        });

        //txtType,txtName,txtPhone,txtDescription,txtDate,txtLocation;
    }
}