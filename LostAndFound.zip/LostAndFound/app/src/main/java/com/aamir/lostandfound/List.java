package com.aamir.lostandfound;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class List extends AppCompatActivity {

    Spinner cmbList;
    DBsqLite dbSQLITE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        cmbList=(Spinner) findViewById(R.id.cmbList);
        dbSQLITE=new DBsqLite(this);

        java.util.List<String> list=dbSQLITE.fillList();
        ArrayAdapter<String> arrayAdapter=new ArrayAdapter<>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,list);
        arrayAdapter.setDropDownViewResource(androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        cmbList.setAdapter(arrayAdapter);

        cmbList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                if(cmbList.getSelectedItemPosition()!=0)
                {
                    Intent intent=new Intent(List.this,Remove.class);
                    intent.putExtra("description",cmbList.getSelectedItem().toString());
                    startActivity(intent);
                    //Toast.makeText(List.this,cmbList.getSelectedItem().toString(),Toast.LENGTH_LONG).show();
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


    }
}